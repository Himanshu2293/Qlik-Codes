
/*
 * Basic responsive mashup template
 * @owner Enter you name here (xxx)
 */
/*
 *    Fill in host and port for Qlik engine
 */
var prefix = window.location.pathname.substr( 0, window.location.pathname.toLowerCase().lastIndexOf( "/extensions" ) + 1 );
var config = {
	host: window.location.hostname,
	prefix: prefix,
	port: window.location.port,
	isSecure: window.location.protocol === "https:"
};
require.config( {
	baseUrl: ( config.isSecure ? "https://" : "http://" ) + config.host + (config.port ? ":" + config.port : "") + config.prefix + "resources"
} );

require( ["js/qlik"], function ( qlik ) {
	qlik.setOnError( function ( error ) {
		$( '#popupText' ).append( error.message + "<br>" );
		$( '#popup' ).fadeIn( 1000 );
	} );
	$( "#closePopup" ).click( function () {
		$( '#popup' ).hide();
	} );

	//callbacks -- inserted here --
	//open apps -- inserted here --
	var app = qlik.openApp('Consumer Sales.qvf', config);

	//get objects -- inserted here --
	app.getObject('KPI-01','ajMAEu');
	app.getObject('KPI-04','NrHfp');
	app.getObject('QV1-01','JcJvj');
	
	app.getObject('QV1-03','RfEbJ');
	app.getObject('QV1-02','bsxkrg');
	
	app.getObject('KPI-03','bJSZttJ');
	app.getObject('KPI-02','ajMAEu');
	
	app.getObject('QV2-02','fNGRa');
	app.getObject('QV3-02','MEAjCJ');
	app.getObject('QV3-01','akDGX');
	app.getObject('QV2-01','vCNaSe');
	
	
	//create cubes and lists -- inserted here --

	if (app) {
		app.getObject('CurrentSelections','CurrentSelections');
		$("li.SideNavButton").click(function() {
			qlik.resize();
		});
	} else {
		$(".current-selections-placeholder span").css("display", "inline-block");
	}

} );
//Custom jquery code to hide and show the content based on selection
		$(document).ready(function() {
			$("li.SideNavButton").click(function(){
				console.log(this);
				var idName = $(this).attr('id');
				console.log(idName);
				$(".ContentPage.Selected").hide().removeClass("Selected");
				$(".ContentPage."+idName).show().addClass("Selected");			
				});			
			});


	



	
	
	

